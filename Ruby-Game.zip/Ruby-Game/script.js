const tg = window.Telegram.WebApp;
tg.expand(); 

// عناصر الشاشات
const scoreDisplay = document.getElementById('score');
const profitDisplay = document.getElementById('profit-display');
const mainClicker = document.getElementById('main-clicker');

const mineScreen = document.getElementById('mine-screen');
const upgradesScreen = document.getElementById('upgrades-screen');
const tasksScreen = document.getElementById('tasks-screen');
const friendsScreen = document.getElementById('friends-screen');

const btnMine = document.getElementById('btn-mine');
const btnUpgrades = document.getElementById('btn-upgrades');
const btnTasks = document.getElementById('btn-tasks');
const btnFriends = document.getElementById('btn-friends');

// الترقيات والأسعار
const clickUpgradeCostDisplay = document.getElementById('click-upgrade-cost');
const passiveUpgradeCostDisplay = document.getElementById('passive-upgrade-cost');

// 1. تحميل البيانات
let score = parseFloat(localStorage.getItem('ember_score')) || 0;
let clickPower = parseInt(localStorage.getItem('ember_click_power')) || 1; 
let profitPerHour = parseInt(localStorage.getItem('ember_profit_hour')) || 150; 

let clickUpgradeCost = parseInt(localStorage.getItem('ember_c_cost')) || 50;
let passiveUpgradeCost = parseInt(localStorage.getItem('ember_p_cost')) || 200;

let isTgTaskDone = localStorage.getItem('task_tg_done') === 'true';
let isYtTaskDone = localStorage.getItem('task_yt_done') === 'true';

function updateUI() {
    scoreDisplay.textContent = Math.floor(score);
    profitDisplay.textContent = `+${profitPerHour}`;
    clickUpgradeCostDisplay.textContent = clickUpgradeCost;
    passiveUpgradeCostDisplay.textContent = passiveUpgradeCost;

    if (isTgTaskDone) {
        document.getElementById('task-tg').textContent = "تم ✅";
        document.getElementById('task-tg').classList.add('done');
    }
    if (isYtTaskDone) {
        document.getElementById('task-yt').textContent = "تم ✅";
        document.getElementById('task-yt').classList.add('done');
    }
}
updateUI();

// 2. نظام التعدين التلقائي
setInterval(() => {
    let profitPerSecond = profitPerHour / 3600;
    score += profitPerSecond;
    scoreDisplay.textContent = Math.floor(score);
    localStorage.setItem('ember_score', score);
}, 1000);

// 3. النقر اليدوي
mainClicker.addEventListener('pointerdown', (event) => {
    score += clickPower;
    scoreDisplay.textContent = Math.floor(score);
    localStorage.setItem('ember_score', score);

    if (tg.HapticFeedback) tg.HapticFeedback.impactOccurred('light');

    const floatElement = document.createElement('div');
    floatElement.classList.add('floating-number');
    floatElement.textContent = `+${clickPower}`;
    floatElement.style.left = `${event.clientX}px`;
    floatElement.style.top = `${event.clientY - 20}px`;
    document.querySelector('.clicker-area').appendChild(floatElement);
    setTimeout(() => floatElement.remove(), 1000);
});

// 4. نظام التنقل والتبديل بين الـ 4 شاشات
function showScreen(activeBtn, screenToShow) {
    [mineScreen, upgradesScreen, tasksScreen, friendsScreen].forEach(s => s.classList.add('hidden'));
    [btnMine, btnUpgrades, btnTasks, btnFriends].forEach(b => b.classList.remove('active'));
    
    screenToShow.classList.remove('hidden');
    activeBtn.classList.add('active');
}

btnMine.addEventListener('click', () => showScreen(btnMine, mineScreen));
btnUpgrades.addEventListener('click', () => showScreen(btnUpgrades, upgradesScreen));
btnTasks.addEventListener('click', () => showScreen(btnTasks, tasksScreen));
btnFriends.addEventListener('click', () => showScreen(btnFriends, friendsScreen));

// 5. شراء الترقيات
document.getElementById('buy-click-upgrade').addEventListener('click', () => {
    if (score >= clickUpgradeCost) {
        score -= clickUpgradeCost;
        clickPower += 1;
        clickUpgradeCost = Math.floor(clickUpgradeCost * 1.5);
        localStorage.setItem('ember_click_power', clickPower);
        localStorage.setItem('ember_c_cost', clickUpgradeCost);
        updateUI();
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    }
});

document.getElementById('buy-passive-upgrade').addEventListener('click', () => {
    if (score >= passiveUpgradeCost) {
        score -= passiveUpgradeCost;
        profitPerHour += 50;
        passiveUpgradeCost = Math.floor(passiveUpgradeCost * 1.6);
        localStorage.setItem('ember_profit_hour', profitPerHour);
        localStorage.setItem('ember_p_cost', passiveUpgradeCost);
        updateUI();
        if (tg.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    }
});

// 6. نظام المهام
document.getElementById('task-tg').addEventListener('click', () => {
    if (!isTgTaskDone) {
        tg.openTelegramLink('https://t.me/telegram'); 
        score += 1000;
        isTgTaskDone = true;
        localStorage.setItem('task_tg_done', 'true');
        localStorage.setItem('ember_score', score);
        updateUI();
    }
});

document.getElementById('task-yt').addEventListener('click', () => {
    if (!isYtTaskDone) {
        tg.openLink('https://youtube.com');
        score += 500;
        isYtTaskDone = true;
        localStorage.setItem('task_yt_done', 'true');
        localStorage.setItem('ember_score', score);
        updateUI();
    }
});

// 7. نظام دعوة الأصدقاء والمشاركة الفورية
document.getElementById('btn-invite-friend').addEventListener('click', () => {
    // جلب الـ ID الفريد للاعب من تليجرام لإنشاء رابط إحالة مخصص له
    const userId = tg.initDataUnsafe.user?.id || "test_user";
    
    // نص رسالة الدعوة والرابط (سنقوم بتغيير 'YOUR_BOT_USERNAME' لاسم بوتك الحقيقي لاحقاً)
    const botLink = `https://t.me/YOUR_BOT_USERNAME/app?startapp=ref_${userId}`;
    const inviteText = encodeURIComponent("🔥 العب معي في لعبة Ember الممتعة! ابنِ فرن التعدين الخاص بك واكسب عملات ذهبية مجانية فوراً! 💰");
    
    // فتح نافذة مشاركة تليجرام الفورية واختيار الشات لإرسال الدعوة
    tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(botLink)}&text=${inviteText}`);
});
